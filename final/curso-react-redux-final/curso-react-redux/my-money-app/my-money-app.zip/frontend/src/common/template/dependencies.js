import './jquery'

import 'admin-lte/plugins/jQueryUI/jquery-ui'
import 'admin-lte/plugins/fastclick/fastclick'
import 'admin-lte/plugins/slimScroll/jquery.slimscroll'
import 'admin-lte/dist/js/app'

import 'font-awesome/css/font-awesome.css'
import 'ionicons/dist/css/ionicons.css'
import 'admin-lte/bootstrap/css/bootstrap.css'
import 'admin-lte/dist/css/AdminLTE.css'
import 'admin-lte/dist/css/skins/_all-skins.css'
import 'admin-lte/plugins/iCheck/flat/blue.css'

import './custom.css'